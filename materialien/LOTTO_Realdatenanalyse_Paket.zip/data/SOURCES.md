# Datenquellen

Abrufdatum: 9. August 2026

Die Dateien in `raw/` sind unveränderte Downloads aus dem offiziellen Downloadbereich von WestLotto:

- `westlotto_lotto6aus49_1955_2021.zip`  
  Quelle: https://www.westlotto.de/westlotto-medien/zahlen-fakten/gewinnzahlendownload/lotto6aus49.zip  
  SHA-256: `5ec50db49035e8b8e778094b9f1e5f9a279dba16363fa9cbd6dd3265a2f0ce2e`
- `westlotto_lotto6aus49_ab2022.zip`  
  Quelle: WestLotto-Infoservice, Parameter: `gruppe=ErgebnisDownload`, `client=wldl`, `jahr_von=2022`, `jahr_bis=2035`, `spielart=LOTTO`, `format=csv`  
  SHA-256: `534932496bfdc8b4b5f3163581dc6cdc5ac3d5edf02746d459842d2573f0c5f7`

Downloadseite: https://www.westlotto.de/service/downloads/downloads.html

Hinweis: WestLotto kennzeichnet die Zahlenangaben als „ohne Gewähr“. Die Analyse verwendet ausschließlich Ziehungsdatum und die sechs Gewinnzahlen; Zusatz-/Superzahl, Quoten und Einsätze werden nicht ausgewertet.

## Dokumentierte Bereinigung

Das Jahresarchiv enthält zwei offenkundige Datumsfehler bei als Samstagsziehung (`SA`) gekennzeichneten Zeilen: `21.07.2014` (Montag) und `20.07.2015` (Montag). Im aufbereiteten Datensatz werden sie auf die zugehörigen Samstage `19.07.2014` beziehungsweise `18.07.2015` korrigiert. Die sechs Gewinnzahlen werden nicht verändert; die Spalte `Datenhinweis` protokolliert beide Korrekturen.
