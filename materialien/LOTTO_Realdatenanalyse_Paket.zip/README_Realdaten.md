# Wenn Symmetrie schwankt – Realdatenanalyse

Dieses Paket untersucht die Lücken in offiziellen Ziehungen von LOTTO 6aus49 ab dem 6. Dezember 2000.

## Ausführen

1. `LOTTO_Realdatenanalyse.ipynb` in Jupyter öffnen.
2. Das Arbeitsverzeichnis muss der Ordner sein, in dem Notebook, `realdaten_analyse.py` und `data/` liegen.
3. Alle Zellen ausführen.

Benötigt werden Python 3, NumPy, pandas, Matplotlib, openpyxl und Jupyter. Alle Ergebnisse werden relativ im Ordner `output_realdaten/` erzeugt.

## Inhalt

- `data/raw/`: unveränderte offizielle WestLotto-Downloads
- `data/SOURCES.md`: Quellen, Abrufdatum, Prüfsummen und Bereinigungsprotokoll
- `realdaten_analyse.py`: Einlese-, Prüf- und Auswertungsfunktionen
- `LOTTO_Realdatenanalyse.ipynb`: didaktisch strukturierte Analyse
- `output_realdaten/`: erzeugte CSV-, Excel-, PNG- und PDF-Dateien

Die Hauptanalyse umfasst Gesamtmittelwerte, 95%-Intervalle, Mittwoch/Samstag, feste Fünfjahresblöcke und gleitende Fenster von 200 Ziehungen.
