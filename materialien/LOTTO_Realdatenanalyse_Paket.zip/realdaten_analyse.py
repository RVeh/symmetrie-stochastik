"""Reproduzierbare Analyse offizieller LOTTO-6aus49-Ziehungen."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd


STARTDATUM = pd.Timestamp("2000-12-06")
THEORIE_X = np.arange(1, 7) * 50 / 7
THEORIE_U = np.repeat(43 / 7, 7)
X_SPALTEN = [f"X_{j}" for j in range(1, 7)]
U_SPALTEN = [f"U_{j}" for j in range(1, 8)]


def _historische_daten(pfad: Path) -> pd.DataFrame:
    """Liest die homogenen Ziehungen vom 06.12.2000 bis Ende 2021."""
    with zipfile.ZipFile(pfad) as archiv:
        name = next(n for n in archiv.namelist() if n.lower().endswith(".xlsx"))
        excel_bytes = archiv.read(name)
    teile = []
    for jahr in range(2000, 2022):
        roh = pd.read_excel(io.BytesIO(excel_bytes), sheet_name=str(jahr), header=None)
        datum_roh = roh.iloc[:, 1]
        textdatum = datum_roh.astype("string").str.strip()
        fehlt = textdatum.str.match(r"^\d{2}\.\d{2}\.$", na=False)
        datum = pd.to_datetime(datum_roh.where(~fehlt), errors="coerce")
        # In den Blättern 2013–2016 fehlt bei Datumsangaben das Jahr.
        ergaenzt = pd.to_datetime(
            textdatum[fehlt].str.rstrip(".") + f".{jahr}",
            format="%d.%m.%Y", errors="coerce"
        )
        # KW 1 kann bereits Ende Dezember des Vorjahres beginnen.
        vorjahres_kw1 = (ergaenzt.dt.month == 12) & (ergaenzt.index < 10)
        ergaenzt.loc[vorjahres_kw1] = ergaenzt.loc[vorjahres_kw1] - pd.DateOffset(years=1)
        datum.loc[fehlt] = ergaenzt
        teil = pd.DataFrame({"Datum": datum})
        teil["Ziehung"] = roh.iloc[:, 2].astype("string").str.strip().str.upper()
        for k, spalte in enumerate(X_SPALTEN, start=3):
            teil[spalte] = pd.to_numeric(roh.iloc[:, k], errors="coerce")
        teile.append(teil)
    daten = pd.concat(teile, ignore_index=True)
    return daten.loc[daten["Datum"].ge(STARTDATUM)].copy()


def _aktuelle_daten(pfad: Path) -> pd.DataFrame:
    """Liest die vom WestLotto-Infoservice gelieferte CSV ab 2022."""
    with zipfile.ZipFile(pfad) as archiv:
        name = next(n for n in archiv.namelist() if n.lower().endswith(".csv"))
        text = archiv.read(name).decode("cp1252")
    roh = pd.read_csv(io.StringIO(text), sep=";", header=None, skiprows=1, dtype=str)
    daten = pd.DataFrame({"Datum": pd.to_datetime(roh.iloc[:, 0].str.strip(), dayfirst=True, errors="coerce")})
    for j, spalte in enumerate(X_SPALTEN, start=2):
        daten[spalte] = pd.to_numeric(roh.iloc[:, j].str.strip(), errors="coerce")
    daten["Ziehung"] = daten["Datum"].dt.dayofweek.map({2: "MI", 5: "SA"}).astype("string")
    return daten


def lade_und_pruefe(rohdatenordner: Path | str = "data/raw") -> pd.DataFrame:
    """Lädt beide Originalarchive, sortiert Gewinnzahlen und prüft jede Ziehung."""
    basis = Path(rohdatenordner)
    alt = _historische_daten(basis / "westlotto_lotto6aus49_1955_2021.zip")
    neu = _aktuelle_daten(basis / "westlotto_lotto6aus49_ab2022.zip")
    daten = pd.concat([alt, neu], ignore_index=True).dropna(subset=["Datum", *X_SPALTEN])
    daten["Datenhinweis"] = ""
    # Zwei offenkundige Datumsfehler im offiziellen Jahresarchiv: Die als SA
    # bezeichneten Daten liegen dort an einem Montag. Gewinnzahlen bleiben unverändert.
    korrekturen = {
        pd.Timestamp("2014-07-21"): pd.Timestamp("2014-07-19"),
        pd.Timestamp("2015-07-20"): pd.Timestamp("2015-07-18"),
    }
    for falsch, richtig in korrekturen.items():
        maske = daten["Datum"].eq(falsch) & daten["Ziehung"].eq("SA")
        daten.loc[maske, "Datenhinweis"] = f"Quelldatum {falsch:%d.%m.%Y} auf {richtig:%d.%m.%Y} korrigiert"
        daten.loc[maske, "Datum"] = richtig
    daten[X_SPALTEN] = np.sort(daten[X_SPALTEN].to_numpy(dtype=int), axis=1)
    daten = daten.sort_values("Datum").drop_duplicates("Datum", keep="last").reset_index(drop=True)

    x = daten[X_SPALTEN].to_numpy(dtype=int)
    fehler = []
    if not np.all((x >= 1) & (x <= 49)):
        fehler.append("Gewinnzahl außerhalb 1 bis 49")
    if not np.all(np.diff(x, axis=1) > 0):
        fehler.append("nicht sechs verschiedene Gewinnzahlen")
    if not daten["Ziehung"].isin(["MI", "SA"]).all():
        fehler.append("unbekannter Ziehungstag")
    wochentag_ok = ((daten["Ziehung"].eq("MI") & daten["Datum"].dt.dayofweek.eq(2)) |
                    (daten["Ziehung"].eq("SA") & daten["Datum"].dt.dayofweek.eq(5)))
    if not wochentag_ok.all():
        fehler.append("Datum und Ziehungstag widersprechen sich")
    if daten["Datum"].duplicated().any():
        fehler.append("doppeltes Datum")
    if fehler:
        raise ValueError("Datenprüfung fehlgeschlagen: " + "; ".join(fehler))

    u = np.column_stack([x[:, 0] - 1, np.diff(x, axis=1) - 1, 49 - x[:, -1]])
    if not (np.all(u >= 0) and np.all(u.sum(axis=1) == 43)):
        raise AssertionError("Lückenprüfung fehlgeschlagen")
    daten[U_SPALTEN] = u
    daten["Jahr"] = daten["Datum"].dt.year
    return daten


def kennwerte(daten: pd.DataFrame, spalten: list[str], theorie: np.ndarray) -> pd.DataFrame:
    """Mittel, Streuung, Standardfehler und approximatives 95%-Intervall."""
    n = len(daten)
    mittel = daten[spalten].mean().to_numpy()
    std = daten[spalten].std(ddof=1).to_numpy()
    se = std / np.sqrt(n)
    return pd.DataFrame({
        "Variable": spalten,
        "n": n,
        "Mittelwert": mittel,
        "Theorie": theorie,
        "Abweichung": mittel - theorie,
        "Standardabweichung": std,
        "Standardfehler": se,
        "KI_95_unten": mittel - 1.96 * se,
        "KI_95_oben": mittel + 1.96 * se,
    })


def blockanalyse(daten: pd.DataFrame, breite: int = 5) -> pd.DataFrame:
    """Bildet feste Kalenderblöcke; der erste unvollständige Block bleibt sichtbar."""
    start = (daten["Jahr"].min() // breite) * breite
    blockstart = start + ((daten["Jahr"] - start) // breite) * breite
    beschriftung = blockstart.astype(str) + "–" + (blockstart + breite - 1).astype(str)
    return daten.assign(Zeitraum=beschriftung).groupby("Zeitraum", sort=True)[X_SPALTEN + U_SPALTEN].agg(["count", "mean", "std"])


def gleitende_mittel(daten: pd.DataFrame, fenster: int = 200) -> pd.DataFrame:
    """Zentrierte gleitende Mittel über eine feste Zahl aufeinanderfolgender Ziehungen."""
    if fenster < 2 or fenster > len(daten):
        raise ValueError("Fenstergröße muss zwischen 2 und der Zahl der Ziehungen liegen.")
    roll = daten[U_SPALTEN].rolling(fenster, center=True, min_periods=fenster).mean()
    return pd.concat([daten[["Datum"]], roll], axis=1).dropna().reset_index(drop=True)


def exportiere_excel(daten, gesamt, nach_tag, bloecke, rollend, pfad):
    """Schreibt alle aufbereiteten Daten und Ergebnisse in eine Excel-Arbeitsmappe."""
    with pd.ExcelWriter(pfad, engine="openpyxl") as writer:
        daten.to_excel(writer, sheet_name="Ziehungen_und_Luecken", index=False)
        gesamt.to_excel(writer, sheet_name="Gesamt", index=False)
        nach_tag.to_excel(writer, sheet_name="Mittwoch_Samstag", index=False)
        bloecke.to_excel(writer, sheet_name="Fuenfjahresbloecke")
        rollend.to_excel(writer, sheet_name="Gleitende_Fenster", index=False)
